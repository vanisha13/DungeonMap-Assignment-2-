#ifndef DUNGEONMAP_H
#define DUNGEONMAP_H

#include <vector>
#include <utility> // for std::pair

class DungeonMap {
public:
    DungeonMap(int rows, int cols);
    bool findPath();
    void printMap();

private:
    bool dfs(int x, int y);
    bool isValid(int x, int y);

    int rows, cols;
    std::vector<std::vector<char>> map;
    std::pair<int, int> start, end; // Start and end positions
};

#endif // DUNGEONMAP_H
