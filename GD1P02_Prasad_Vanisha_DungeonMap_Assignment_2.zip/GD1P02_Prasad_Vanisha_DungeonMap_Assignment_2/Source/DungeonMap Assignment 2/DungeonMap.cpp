#include "DungeonMap.h"
#include <iostream>

DungeonMap::DungeonMap(int rows, int cols) : rows(rows), cols(cols) {
    // Initialize the map with empty spaces ('.') and define the start and end points
    map.resize(rows, std::vector<char>(cols, '.'));
    start = { 0, 0 }; // Starting position 'P'
    end = { rows - 1, cols - 1 }; // Ending position 'E'
    map[start.first][start.second] = 'P';
    map[end.first][end.second] = 'E';
}

bool DungeonMap::isValid(int x, int y) {
    // Check if (x, y) is within the bounds of the map
    return x >= 0 && x < rows && y >= 0 && y < cols && (map[x][y] == '.' || map[x][y] == 'E');
}

bool DungeonMap::dfs(int x, int y) {
    std::cout << "Visiting: (" << x << ", " << y << ")" << std::endl; // Debugging output

    // If we reach the end, return true
    if (x == end.first && y == end.second) {
        map[x][y] = '*'; // Mark the end as part of the path
        return true;
    }

    // Mark current cell as visited
    map[x][y] = '*';

    // Explore neighboring cells in a fixed order: down, right, up, left
    int directions[4][2] = { {1, 0}, {0, 1}, {-1, 0}, {0, -1} };
    for (auto& direction : directions) {
        int newX = x + direction[0];
        int newY = y + direction[1];

        if (isValid(newX, newY)) {
            if (dfs(newX, newY)) {
                return true;
            }
        }
    }

    // Backtrack (unmark the current cell if no path is found)
    map[x][y] = '.'; // Unmark if we couldn't find a path
    return false;
}

bool DungeonMap::findPath() {
    return dfs(start.first, start.second);
}

void DungeonMap::printMap() {
    // Ensure that the exit 'E' is marked after DFS completes
    map[end.first][end.second] = 'E';

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cout << map[i][j] << " ";
        }
        std::cout << std::endl;
    }
}
