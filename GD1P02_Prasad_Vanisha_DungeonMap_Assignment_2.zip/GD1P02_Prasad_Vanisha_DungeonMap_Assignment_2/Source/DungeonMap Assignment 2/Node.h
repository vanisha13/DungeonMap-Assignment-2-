#ifndef NODE_H
#define NODE_H

struct Node {
    int x, y;          // Position
    int gCost = 0;     // Cost from start node
    int hCost = 0;     // Heuristic cost to end node
    Node* parent = nullptr; // Pointer to parent node for path reconstruction

    Node(int xPos, int yPos) : x(xPos), y(yPos) {}

    // Calculates the total cost (F = G + H)
    int getFCost() const {
        return gCost + hCost;
    }

    // Equality operator for comparing nodes
    bool operator==(const Node& other) const {
        return x == other.x && y == other.y;
    }
};

#endif // NODE_H
