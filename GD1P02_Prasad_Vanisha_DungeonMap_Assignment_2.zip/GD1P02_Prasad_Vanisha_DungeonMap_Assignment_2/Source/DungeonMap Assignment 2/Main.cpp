#include <iostream>
#include "DungeonMap.h"

int main() {
    int rows, cols;

    // Input the map dimensions
    std::cout << "Enter the number of rows: ";
    std::cin >> rows;
    std::cout << "Enter the number of columns: ";
    std::cin >> cols;

    // Create the dungeon map
    DungeonMap dungeon(rows, cols);

    // Display the initial map
    std::cout << "Initial Map:" << std::endl;
    dungeon.printMap();

    // Find the path
    if (dungeon.findPath()) {
        std::cout << "Path found!" << std::endl;
    }
    else {
        std::cout << "No path found!" << std::endl;
    }

    // Display the map after pathfinding
    std::cout << "Path:" << std::endl;
    dungeon.printMap();

    return 0;
}
