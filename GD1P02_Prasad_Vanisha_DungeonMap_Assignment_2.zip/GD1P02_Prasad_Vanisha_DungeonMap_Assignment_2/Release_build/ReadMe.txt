Dungeon Pathfinding Project
Overview
This project is a pathfinding application that solves a dungeon represented as a grid. The program finds a path from the starting point (P) to the ending point (E) using a recursive approach. It visualizes the path using asterisks (*) and displays the solved map.

Files
The project consists of the following files:

1. node.h
Defines the Node structure for representing grid cells.
Includes attributes like row, column, and status indicators for visited and path markers.

2. dungeon.h
Declares the DungeonMap class.
Contains function declarations for:
Creating and managing the dungeon grid.
Setting start and end points.
Validating moves.
Finding paths recursively.

3. dungeon.cpp
Implements the DungeonMap class methods.
Handles the logic for:
Initializing the grid.
Displaying the initial and solved maps.
Recursively solving the dungeon path.
Marking the path from start to end.

4. main.cpp
Provides the entry point of the application.
Collects user input for grid size, start point, and end point.
Calls the DungeonMap methods to initialize, solve, and display the dungeon.

How to Run
Compile the code:
Use a C++ compiler like g++ or an IDE like Visual Studio.

Ensure all files (node.h, dungeon.cpp, dungeon.h, and main.cpp) are included in the project.

Example (using g++):
g++ main.cpp dungeon.cpp -o dungeon_solver

Run the program:
./dungeon_solver

Provide inputs:
Enter the number of rows and columns for the grid.
Specify the starting point (row and column).
Specify the ending point (row and column).
View the output:

The program displays the initial grid with P and E.
After solving, it displays the path marked with *.
Example Usage
Input:
Enter the number of rows: 5
Enter the number of columns: 5
Enter the starting point (row and column): 0 0
Enter the ending point (row and column): 4 4

Output:
Initial Map:
P . . . .
. . . . .
. . . . .
. . . . .
. . . . E
Solved Map:
P * * * *
* * * * *
* * * * *
* * * * *
* * * * E

Features
Recursive pathfinding.
Visualization of the path with *.
User-defined grid size, start point, and end point.

Requirements
C++17 or higher.
IDE or compiler with support for C++ (e.g., Visual Studio, g++, or Clang).

Future Enhancements
Add obstacles to the grid for more challenging pathfinding.
Implement alternate algorithms like BFS or Dijkstra's for comparison.
Allow dynamic resizing of the grid during runtime.

Author
Vanisha Prasad